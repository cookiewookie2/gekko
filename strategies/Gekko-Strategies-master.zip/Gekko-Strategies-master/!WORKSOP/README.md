Strategies in this directory may not work, they may be duplicated (I have filtered through checksums). The source is in source.txt files

Part of the strategies from here was written at a time when Gekko did not have UI yet, and traders only used CLI. Because of this, their settings are not in the TOML files directory. To find settings for this strategy, you have to go to the source and open the config.js (or something similar) file in the root directory. Strategies from older versions of Gekko you will match from him directory in source (gekko/methods instead gekko/strategies).

Have fun!
